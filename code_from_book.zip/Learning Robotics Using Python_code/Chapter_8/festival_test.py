#!/usr/bin/env python
import festival
festival.say("Hello World")
